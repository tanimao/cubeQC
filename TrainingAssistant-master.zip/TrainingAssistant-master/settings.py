# -*- coding: utf-8 -*-

#Search Word
word = u''

#API Key
key = ''
